﻿using Employee.Data.models;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {

        private IEmployee emptest = new EmployeeTest();

        /*  public List<Emp> Employees;
       public EmployeeController()
       {



           Employees = new List<Emp>()
           {
               new Emp() { id= 1, Name="Asritha",Salary=35000,Permanent=true, Department= new Department( 1,"CDE") ,Skills=new List<Skill>(){ new Skill ( 1,"java"), new Skill(2,"c#" ) }, DateOfBirth=new DateTime(1999,10,26) },
                new Emp() { id= 2, Name="Harika",Salary=25000,Permanent=true, Department= new Department( 2,"IT") ,Skills=new List<Skill>(){ new Skill ( 3,"python"), new Skill(1,"java" ) }, DateOfBirth=new DateTime(1997,06,09) }


           };
       }*/


        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IEnumerable<Emp> Get() => emptest.GetStandardEmployeeList();


        [HttpGet("Employee/getstandard")]
        public ActionResult<Emp> GetStandard()
        {
            return emptest.GetStandard();
        }
        [HttpGet("{id}")]
        public Emp GetEmployeeById(int id)
        {
            return emptest.GetEmployeeById(id);
        }

        [HttpPost("AddEmployee")]
        public void Post(Emp em)
        {
           emptest.AddEmployee(em);
        }
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Emp em)
        {
          emptest.updateEmployee(id,em);
        }
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            emptest.RemoveEmployee(id);
        }

    }
}
