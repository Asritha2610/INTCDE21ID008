﻿namespace Employee.Data.models
{
    public class Department
    {
        public Department()
        { }
        public Department(int DepID, string DepName)
        {
            this.DepID = DepID;
            this.DepName = DepName;
        }
        public int DepID { get; set; }
        public string DepName { get; set; }

    }
}