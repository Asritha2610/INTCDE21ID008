﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Data.models
{
    public class EmployeeTest : IEmployee
    {
        static List<Emp> Employees = new List<Emp>()
             {
                 new Emp{ id = 1, Name ="Asritha",Salary = 35000,Permanent = true, Department = new Department(1, "CDE") ,Skills = new List<Skill>() { new Skill(1, "java"), new Skill(2, "c#") }, DateOfBirth = new DateTime(1999, 10, 26) },
                  new Emp{ id = 2, Name ="Harika",Salary = 25000,Permanent = true, Department = new Department(2, "IT") ,Skills = new List<Skill>() { new Skill(3, "python"), new Skill(1, "java") }, DateOfBirth = new DateTime(1997, 06, 09) }


              };
        public EmployeeTest()
        {

        }

        public void AddEmployee(Emp emp)
        {


            /*Emp ems = new Emp();
            ems.id = emp.id;
            ems.Name = emp.Name;
            ems.Permanent = emp.Permanent;
            ems.Salary = emp.Salary;
            ems.Skills = emp.Skills;
            ems.Department = emp.Department;
            ems.DateOfBirth = emp.DateOfBirth;*/
            Employees.Add(emp);

        }


        public IEnumerable<Emp> GetStandardEmployeeList()
        {
            return Employees;
        }

        public ActionResult<Emp> GetStandard()
        {
            return Employees.Where(i => i.Permanent == true).FirstOrDefault();
        }

        public Emp GetEmployeeById(int id)
        {
            Emp em = null;
            em = Employees.Find(e => e.id == id);
            return em;

        }

        public void updateEmployee(int empid, Emp em)
        {
            Emp emp = null;
            emp = Employees.Find(e => e.id == empid);

            if (emp != null)
            {
                emp.id = em.id;
                emp.Name = em.Name;
                emp.Permanent = em.Permanent;
                emp.Salary = em.Salary;
                emp.Skills = em.Skills;
                emp.Department = em.Department;
                emp.DateOfBirth = em.DateOfBirth;



            }

        }
        public void RemoveEmployee(int empid)
        {
            Emp emp = null;
            emp = Employees.Find(e => e.id == empid);
            if (emp != null)
            {
                Employees.Remove(emp);
            }


            }
    }

}

