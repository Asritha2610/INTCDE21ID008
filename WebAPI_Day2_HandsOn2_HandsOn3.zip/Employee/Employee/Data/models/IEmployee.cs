﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Data.models
{
    interface IEmployee
    {
        IEnumerable<Emp> GetStandardEmployeeList();
        ActionResult<Emp> GetStandard();
       Emp GetEmployeeById(int id);
        void AddEmployee(Emp emp);
        void updateEmployee(int empid, Emp em);
        void RemoveEmployee(int empid);
    }
}
