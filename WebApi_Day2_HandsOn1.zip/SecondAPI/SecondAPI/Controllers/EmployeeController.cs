﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SecondAPI.Data.Models;
using Microsoft.AspNetCore.Http;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SecondAPI.Controllers
{
    [Route("api/Emp")]
    [ApiController]
    public class EmployeeController : ControllerBase

    {
        private List<Employee> Employees;
        public EmployeeController() => Employees = new List<Employee>()
            {
                new Employee() { Id= 1, Name="Asritha",Salary=30000,Permanent=true, Department= new Department( 1,"CDE") ,Skills=new List<Skills>(){ new Skills ( "java",1), new Skills("c#",4 ) }, DateOfBirth=new DateTime(1999,10,26) },
                 new Employee() { Id= 2, Name="Harika",Salary=25000,Permanent=true, Department= new Department( 2,"IT") ,Skills=new List<Skills>(){ new Skills ( "python",2), new Skills("ML",3 ) }, DateOfBirth=new DateTime(1997,06,09) },
                 new Employee() { Id= 3, Name="Anvitha",Salary=20000,Permanent=true, Department= new Department( 3,"CSD") ,Skills=new List<Skills>(){ new Skills ( "python",2), new Skills("c#",4 ) }, DateOfBirth=new DateTime(1998,12,03) }


            };

        private List<Employee> GetStandardEmployeeList()
        {
            return Employees;
        }

        [HttpGet]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public IEnumerable<Employee> Get()
        {
            return GetStandardEmployeeList();
        }


        [HttpGet("Employee/getstandard")]
        public ActionResult<Employee> GetStandard()
        {
            return Employees.Where(i => i.Permanent == true).FirstOrDefault();
        }


        // GET: api/<EmployeeController>
             

        // GET api/<EmployeeController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<EmployeeController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<EmployeeController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {

        }

        // DELETE api/<EmployeeController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
