﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SecondAPI.Data.Models
{
    
    public class Department
    {
        private int id;
        private string name;

       

        public Department(int id, string name)
        {
            this.id = DeptId;
            this.name = DeptName;
        }

        public string DeptName { get; set; }
        public int DeptId { get; set; }
    }
}
