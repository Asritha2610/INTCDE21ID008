﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SecondAPI.Data.Models
{
    public class Employee
    {
        public Employee() { }
        public Employee(int id,string name,int salary,bool permanent,Department dept,List<Skills>skill,DateTime dt)
        {
            this.Id = id;
            this.Name = name;
            this.Salary = salary;
            this.Permanent = permanent;
            this.Department = dept;
            this.Skills = skill;
            this.DateOfBirth = dt;

        }
       
        
        public int Id { get; set; }

        public string Name { get; set; }

        public int Salary { get; set; }

        public bool Permanent { get; set; }
        public Department Department { get; set; }
        public List<Skills> Skills { get; set; }

        public DateTime DateOfBirth { get; set; }
    }
}
