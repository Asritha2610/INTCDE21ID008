﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SecondAPI.Data.Models
{
    public class Skills
    {
        public Skills(string sname, int sid)
        {
            this.Sname = sname;
            this.Sid = sid;
        }
        public string Sname{get;set;}
        public int Sid { get; set; }
    }
}
